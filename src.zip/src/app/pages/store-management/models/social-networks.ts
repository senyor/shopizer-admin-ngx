export class SocialNetworks {
  id: number;
  active: boolean;
  key: string;
  value: string;
  type: string;
}
