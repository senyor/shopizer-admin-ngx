import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-retailer-list',
  templateUrl: './retailer-list.component.html',
  styleUrls: ['./retailer-list.component.scss']
})
export class RetailerListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
