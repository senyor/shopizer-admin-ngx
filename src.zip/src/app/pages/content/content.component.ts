import { Component } from '@angular/core';

@Component({
  selector: 'ngx-content-management',
  templateUrl: './content.component.html',
  // styleUrls: ['./user-management.component.scss']
})
// @Component({
//   selector: 'ngx-tables',
//   template: `<router-outlet></router-outlet>`,
// })
export class ContentComponent {

}
