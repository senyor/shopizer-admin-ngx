import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {
  path = 'Catalogue / Category';

  constructor() {
  }

  ngOnInit() {
  }

}
