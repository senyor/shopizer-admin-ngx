import { Component } from '@angular/core';


@Component({
  selector: 'ngx-customer',
  templateUrl: './customer.component.html',
})

export class CustomersComponent {

}
