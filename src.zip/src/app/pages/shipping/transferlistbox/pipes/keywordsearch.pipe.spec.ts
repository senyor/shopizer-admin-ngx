import { KeywordsearchPipe } from './keywordsearch.pipe';

describe('KeywordsearchPipe', () => {
  it('create an instance', () => {
    const pipe = new KeywordsearchPipe();
    expect(pipe).toBeTruthy();
  });
});
