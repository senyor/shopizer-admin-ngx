import { Component } from '@angular/core';


@Component({
  selector: 'ngx-shipping',
  templateUrl: './shipping.component.html',
})

export class ShippingComponent {

}
